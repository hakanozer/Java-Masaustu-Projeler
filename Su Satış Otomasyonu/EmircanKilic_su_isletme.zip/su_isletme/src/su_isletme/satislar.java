/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package su_isletme;

import java.sql.ResultSet;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class satislar extends javax.swing.JFrame {

    public satislar() {
        initComponents();
        tabloDoldur();
    }

    public void tabloDoldur() {

        DB db = new DB();
        DefaultTableModel dt = new DefaultTableModel();
        dt.addColumn("Satis Id");
        dt.addColumn("Müşteri Adı");
        dt.addColumn("Damacana Boyutu(L)");
        dt.addColumn("Adet");
        dt.addColumn("Fiyat");
        dt.addColumn("Durum");

        try {
            
            int fiyat = 0;
            ResultSet rs = db.baglan().executeQuery("Select * from satislar left join turler on satislar.tur_id = turler.tur_id left join musteriler on satislar.musteri_id=musteriler.musteri_id");
            while (rs.next()) {
                fiyat = Integer.parseInt(rs.getString("fiyat").toString())*Integer.parseInt(rs.getString("adet").toString());
               
                dt.addRow(new String[]{rs.getString("satis_id"), rs.getString("adi") + " " + rs.getString("soyadi"), rs.getString("boyut"), rs.getString("adet"),fiyat+"",rs.getString("durum")});

            }
            jTable1.setModel(dt);
                
        } catch (Exception e) {
        }

    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();
        jXDatePicker1 = new org.jdesktop.swingx.JXDatePicker();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jXDatePicker2 = new org.jdesktop.swingx.JXDatePicker();
        jButton1 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jScrollPane1.setViewportView(jTable1);

        jLabel1.setText("Başlangıç:");

        jLabel2.setText("Bitiş:");

        jButton1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/su_isletme/1466510607_sign-up.png"))); // NOI18N
        jButton1.setText("Getir");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 644, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jXDatePicker1, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel2)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jXDatePicker2, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(84, 84, 84)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jXDatePicker1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jXDatePicker2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jButton1))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

        
        DB db = new DB();
        boolean durum = false;
        DefaultTableModel dm = new DefaultTableModel();
        dm.addColumn("Satış Id");
        dm.addColumn("Müşteri Adı");
        dm.addColumn("Damacana Boyutu(L)");
        dm.addColumn("Adet");
        dm.addColumn("Fiyat");
        dm.addColumn("Durum");
        
        if(jXDatePicker1.getDate()!=null && jXDatePicker2.getDate()!=null){
            
            durum = true;
            
        }
        
        if(durum){
            if(jXDatePicker2.getDate().after(jXDatePicker1.getDate())){
                SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd HH-mm-ss");
                System.out.println(formater.format(jXDatePicker1.getDate()));
                try {
                    int fiyat = 0;

                    String a = "Select * from satislar left join musteriler on satislar.musteri_id = musteriler.musteri_id left join turler on satislar.tur_id=turler.tur_id where siparis_tarih > '" + formater.format(jXDatePicker1.getDate()) + "' and siparis_tarih < '" + formater.format(jXDatePicker2.getDate()) + "'";
                    ResultSet rs = db.baglan().executeQuery(a);
                    while (rs.next()) {

                        fiyat = Integer.parseInt(rs.getString("fiyat").toString())*Integer.parseInt(rs.getString("adet").toString());          
                        dm.addRow(new String[]{rs.getString("satis_id"), rs.getString("adi") + " " + rs.getString("soyadi"), rs.getString("boyut"), rs.getString("adet"),fiyat+"",rs.getString("durum")});

                    }
                    jTable1.setModel(dm);

                } catch (Exception e) {
                }
            }else{
                
                JOptionPane.showMessageDialog(this, "Bitiş tarihi Başlangıç tarihinden önce olamaz");
                
            }
        }else{
            
            JOptionPane.showMessageDialog(this, "Lütfen bir giriş ve çıkış tarihi seçiniz...");
            
        }
    }//GEN-LAST:event_jButton1ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(satislar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(satislar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(satislar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(satislar.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new satislar().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    private org.jdesktop.swingx.JXDatePicker jXDatePicker1;
    private org.jdesktop.swingx.JXDatePicker jXDatePicker2;
    // End of variables declaration//GEN-END:variables
}
