/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package su_isletme;

import java.sql.ResultSet;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author java3
 */
public class iletilenler extends javax.swing.JFrame {

    /**
     * Creates new form iletilenler
     */
    public iletilenler() {
        initComponents();
        tabloDoldur();
    }

    public void tabloDoldur() {

        DB db = new DB();
        DefaultTableModel dt = new DefaultTableModel();
        dt.addColumn("Satis Id");
        dt.addColumn("Müşteri Adı");
        dt.addColumn("Damacana Boyutu(L)");
        dt.addColumn("Adet");
        dt.addColumn("Fiyat");
        dt.addColumn("Durum");

        try {
            
            int fiyat = 0;
            ResultSet rs = db.baglan().executeQuery("Select * from satislar left join turler on satislar.tur_id = turler.tur_id left join musteriler on satislar.musteri_id=musteriler.musteri_id where durum='iletildi'");
            while (rs.next()) {
                fiyat = Integer.parseInt(rs.getString("fiyat").toString())*Integer.parseInt(rs.getString("adet").toString());
               
                dt.addRow(new String[]{rs.getString("satis_id"), rs.getString("adi") + " " + rs.getString("soyadi"), rs.getString("boyut"), rs.getString("adet"),fiyat+"",rs.getString("durum")});

            }
            jTable1.setModel(dt);
            jTable1.getColumnModel().getColumn(0).setWidth(5);
            
        } catch (Exception e) {
        }

    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jTable1 = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jScrollPane1.setViewportView(jTable1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 877, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(iletilenler.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(iletilenler.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(iletilenler.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(iletilenler.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new iletilenler().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable1;
    // End of variables declaration//GEN-END:variables
}
