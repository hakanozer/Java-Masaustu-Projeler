/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 100113
Source Host           : localhost:3306
Source Database       : sucu

Target Server Type    : MYSQL
Target Server Version : 100113
File Encoding         : 65001

Date: 2016-07-18 11:36:06
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for musteriler
-- ----------------------------
DROP TABLE IF EXISTS `musteriler`;
CREATE TABLE `musteriler` (
  `musteri_id` int(11) NOT NULL AUTO_INCREMENT,
  `adi` varchar(255) COLLATE utf8_turkish_ci DEFAULT NULL,
  `soyadi` varchar(255) COLLATE utf8_turkish_ci DEFAULT NULL,
  `tel` varchar(255) COLLATE utf8_turkish_ci DEFAULT NULL,
  `adres` varchar(500) COLLATE utf8_turkish_ci DEFAULT NULL,
  PRIMARY KEY (`musteri_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

-- ----------------------------
-- Records of musteriler
-- ----------------------------
INSERT INTO `musteriler` VALUES ('2', 'Metin', 'Sonmez', '05544444444', 'z mahallesi x caddesi y sokak apartman:a daire:b');
INSERT INTO `musteriler` VALUES ('3', 'Emircan', 'Kılıç', '05322342030', 'Seyrantepe Mahallesi Çekimser Sokak 37/2');
INSERT INTO `musteriler` VALUES ('4', 'Samet ', 'Topçu', '05333215674', 'Beylikdüzü/İstanbul');
INSERT INTO `musteriler` VALUES ('5', 'Metin', 'Bilir', '02125847896', 'Gül Caddesi Sümbül Sokak 25/3');
INSERT INTO `musteriler` VALUES ('6', 'Dilek', 'Güler', '05348547896', 'Zebra Mahallesi Aslan Sokak 19/5');
INSERT INTO `musteriler` VALUES ('7', 'Metin', 'Dilsiz', '05532215847', 'Ahmet Sokak Mehmet Caddesi No:26 Daire:2');
INSERT INTO `musteriler` VALUES ('8', 'Veli', 'Kılıç', '02122811384', 'Tuncay Sokak Nihat Caddesi Hamit Apartman? Daire:11');

-- ----------------------------
-- Table structure for satislar
-- ----------------------------
DROP TABLE IF EXISTS `satislar`;
CREATE TABLE `satislar` (
  `satis_id` int(11) NOT NULL AUTO_INCREMENT,
  `musteri_id` int(11) NOT NULL,
  `tur_id` int(11) NOT NULL,
  `durum` varchar(255) COLLATE utf8_turkish_ci DEFAULT 'iletilmedi',
  `siparis_tarih` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `adet` int(11) DEFAULT '1',
  PRIMARY KEY (`satis_id`,`musteri_id`,`tur_id`),
  KEY `fk_musteri` (`musteri_id`),
  KEY `fk_tur` (`tur_id`),
  CONSTRAINT `fk_musteri` FOREIGN KEY (`musteri_id`) REFERENCES `musteriler` (`musteri_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_tur` FOREIGN KEY (`tur_id`) REFERENCES `turler` (`tur_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

-- ----------------------------
-- Records of satislar
-- ----------------------------
INSERT INTO `satislar` VALUES ('2', '2', '2', 'iletildi', '2016-06-21 13:01:11', '1');
INSERT INTO `satislar` VALUES ('3', '3', '1', 'iletildi', '2016-06-10 12:33:40', '3');
INSERT INTO `satislar` VALUES ('4', '6', '2', null, '2016-06-21 13:21:59', '1');
INSERT INTO `satislar` VALUES ('5', '7', '3', null, '2016-06-21 13:22:15', '3');
INSERT INTO `satislar` VALUES ('6', '7', '2', 'iletilmedi', '2016-06-24 09:23:07', '2');

-- ----------------------------
-- Table structure for turler
-- ----------------------------
DROP TABLE IF EXISTS `turler`;
CREATE TABLE `turler` (
  `tur_id` int(11) NOT NULL AUTO_INCREMENT,
  `boyut` int(11) DEFAULT NULL,
  `fiyat` int(11) DEFAULT NULL,
  PRIMARY KEY (`tur_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

-- ----------------------------
-- Records of turler
-- ----------------------------
INSERT INTO `turler` VALUES ('1', '5', '3');
INSERT INTO `turler` VALUES ('2', '10', '5');
INSERT INTO `turler` VALUES ('3', '20', '8');

-- ----------------------------
-- Procedure structure for fncEkle
-- ----------------------------
DROP PROCEDURE IF EXISTS `fncEkle`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fncEkle`(IN `miktar` int(11),IN `tip` int(11),IN `id` int(11))
BEGIN
	
	insert into satislar values(null,id,tip,'iletilmedi',now(),miktar);

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for fncisimAra
-- ----------------------------
DROP PROCEDURE IF EXISTS `fncisimAra`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fncisimAra`(IN `isim` varchar(255))
BEGIN
	
	select * from musteriler where adi like CONCAT('%',isim,'%') or soyadi like CONCAT('%',isim,'%');

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for fncisimSoyisimAra
-- ----------------------------
DROP PROCEDURE IF EXISTS `fncisimSoyisimAra`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fncisimSoyisimAra`(IN `isim` varchar(255),IN `soyisim` varchar(255))
BEGIN
	
	Select * from musteriler where (adi like CONCAT('%',isim,'%') and soyadi like CONCAT('%',soyisim,'%')) or (adi like CONCAT('%',soyisim,'%') and soyadi like CONCAT('%',isim,'%'));

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for fncKayit
-- ----------------------------
DROP PROCEDURE IF EXISTS `fncKayit`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fncKayit`(IN `isim` varchar(255),IN `soyisim` varchar(255),IN `tel` varchar(255),IN `adres` varchar(255))
BEGIN


INSERT INTO musteriler VALUES(NULL,isim,soyisim,tel,adres);

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for fncSil
-- ----------------------------
DROP PROCEDURE IF EXISTS `fncSil`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fncSil`(IN `id` int(11))
BEGIN

	Delete from musteriler where musteri_id = id;

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for fncUpdate
-- ----------------------------
DROP PROCEDURE IF EXISTS `fncUpdate`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fncUpdate`(IN `isim` varchar(255),IN `soyisim` varchar(255),IN `telno` varchar(255),IN `adress` varchar(255),IN `id` int(11))
BEGIN
	
	Update musteriler SET adi = isim , soyadi = soyisim , tel = telno , adres = adress where musteri_id = id;

END
;;
DELIMITER ;
