/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 100113
Source Host           : localhost:3306
Source Database       : sucu

Target Server Type    : MYSQL
Target Server Version : 100113
File Encoding         : 65001

Date: 2016-06-27 00:55:56
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for tbl_musteri
-- ----------------------------
DROP TABLE IF EXISTS `tbl_musteri`;
CREATE TABLE `tbl_musteri` (
  `musteri_id` int(11) NOT NULL AUTO_INCREMENT,
  `musteri_adi` varchar(255) COLLATE utf8_turkish_ci DEFAULT NULL,
  `musteri_soyadi` varchar(255) COLLATE utf8_turkish_ci DEFAULT NULL,
  `musteri_telefon` int(11) DEFAULT NULL,
  `musteri_adres` varchar(255) COLLATE utf8_turkish_ci DEFAULT NULL,
  PRIMARY KEY (`musteri_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

-- ----------------------------
-- Table structure for tbl_siparis
-- ----------------------------
DROP TABLE IF EXISTS `tbl_siparis`;
CREATE TABLE `tbl_siparis` (
  `siparis_id` int(11) NOT NULL AUTO_INCREMENT,
  `musteri_id` int(11) NOT NULL,
  `adet` int(11) DEFAULT NULL,
  `suLitresi` int(11) DEFAULT NULL,
  `tutar` int(20) DEFAULT NULL,
  `durum` varchar(255) COLLATE utf8_turkish_ci DEFAULT '',
  `tarih` date DEFAULT NULL,
  PRIMARY KEY (`siparis_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci;

-- ----------------------------
-- Procedure structure for proArama
-- ----------------------------
DROP PROCEDURE IF EXISTS `proArama`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proArama`(IN `adi` varchar(255),IN `soyadi` varchar(255))
BEGIN
	SELECT*FROM tbl_musteri WHERE musteri_adi=adi AND musteri_soyadi=soyadi;

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for proclistele
-- ----------------------------
DROP PROCEDURE IF EXISTS `proclistele`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proclistele`()
BEGIN
SELECT*FROM tbl_siparis where DATE(NOW());

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for procsipkayit
-- ----------------------------
DROP PROCEDURE IF EXISTS `procsipkayit`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `procsipkayit`(IN `mid` int(11),IN `adett` int(11),IN `miktarlitre` int(11))
BEGIN
	INSERT INTO tbl_siparis VALUES(NULL,mid,adett,miktarlitre,10,'Yolda');

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for proctarih
-- ----------------------------
DROP PROCEDURE IF EXISTS `proctarih`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proctarih`(IN `bastar` date,IN `bittar` date)
BEGIN
	SELECT*FROM tbl_siparis where tarih >bastar AND tarih<bittar;

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for procteslim
-- ----------------------------
DROP PROCEDURE IF EXISTS `procteslim`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `procteslim`(IN `iddd` int)
BEGIN
	UPDATE tbl_siparis SET durum="Teslim Edildi" where siparis_id=iddd;



END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for procYol
-- ----------------------------
DROP PROCEDURE IF EXISTS `procYol`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `procYol`(IN `iddd` int)
BEGIN
	UPDATE tbl_siparis SET durum="Teslim Edildi" where siparis_id=iddd;



END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for proDuzenle
-- ----------------------------
DROP PROCEDURE IF EXISTS `proDuzenle`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proDuzenle`(IN `id` int,IN `adi` varchar(256),IN `soyadi` varchar(256),IN `telefon` int,IN `adres` varchar(256))
BEGIN
UPDATE tbl_musteri SET musteri_adi=adi,musteri_soyadi=soyadi,musteri_telefon=telefon,musteri_adres=adres WHERE musteri_id=id;

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for prohepsinisil
-- ----------------------------
DROP PROCEDURE IF EXISTS `prohepsinisil`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `prohepsinisil`()
BEGIN
	DELETE FROM tbl_siparis;

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for proinsertsip
-- ----------------------------
DROP PROCEDURE IF EXISTS `proinsertsip`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proinsertsip`(IN `mid` int,IN `adett` int,IN `miktarlitre` int,IN `tutarr` int,IN `datee` date)
BEGIN
	INSERT INTO tbl_siparis VALUES(NULL,mid,adett,miktarlitre,tutarr,'paketlendi',datee);

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for proKayit
-- ----------------------------
DROP PROCEDURE IF EXISTS `proKayit`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proKayit`(IN `musteri_adi` varchar(255),IN `musteri_soyadi` varchar(255),IN `musteri_telefon` int,IN `musteri_adres` varchar(255))
BEGIN
	
INSERT INTO tbl_musteri VALUES(null,musteri_adi,musteri_soyadi,musteri_telefon,musteri_adres);

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for proSil
-- ----------------------------
DROP PROCEDURE IF EXISTS `proSil`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `proSil`(IN `id` int)
BEGIN
DELETE FROM tbl_musteri WHERE musteri_id=id;

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for prosipsil
-- ----------------------------
DROP PROCEDURE IF EXISTS `prosipsil`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `prosipsil`(IN `idd` int)
BEGIN
DELETE FROM tbl_siparis WHERE siparis_id=idd;

END
;;
DELIMITER ;
