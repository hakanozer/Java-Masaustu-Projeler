

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DB {

    private Connection conn = null;
    private Statement st = null;
    private String url = "jdbc:mysql://localhost/";
    private String dbName = "kutuphane?useUnicode=true&characterEncoding=UTF8";
    private String userName = "root";
    private String pw = "";
    private String driver = "com.mysql.jdbc.Driver";
    
    public Statement baglan (){
        
        try {
            
            Class.forName(driver);
            conn = DriverManager.getConnection(url + dbName, userName, pw);
            st = conn.createStatement();
            
        } catch (Exception e) {
            
            System.err.println("Bağlanma Hatası: " + e);
            
        }
        
        return st;
        
    }

}
