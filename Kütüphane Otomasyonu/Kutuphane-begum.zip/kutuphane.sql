/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 100113
Source Host           : localhost:3306
Source Database       : kutuphane

Target Server Type    : MYSQL
Target Server Version : 100113
File Encoding         : 65001

Date: 2016-06-24 09:09:06
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `adi` varchar(255) NOT NULL,
  `sifre` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('1', 'begum', '123');
INSERT INTO `admin` VALUES ('2', 'feraykose', '1234');
INSERT INTO `admin` VALUES ('3', 'gulll', '1');

-- ----------------------------
-- Table structure for kitaplar
-- ----------------------------
DROP TABLE IF EXISTS `kitaplar`;
CREATE TABLE `kitaplar` (
  `kitap_id` int(11) NOT NULL AUTO_INCREMENT,
  `kitap_turu` varchar(255) DEFAULT NULL,
  `kitap_adi` varchar(255) NOT NULL,
  `aciklama` varchar(255) NOT NULL,
  `yazar_adi` varchar(255) NOT NULL,
  `yayinevi` varchar(255) NOT NULL,
  `kitap_dili` varchar(255) NOT NULL,
  `raf_no` int(11) NOT NULL,
  `eklenme_tarihi` datetime DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kitap_id`),
  FULLTEXT KEY `namefullindex` (`kitap_adi`)
) ENGINE=InnoDB AUTO_INCREMENT=45 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of kitaplar
-- ----------------------------
INSERT INTO `kitaplar` VALUES ('1', '1', 'Yuregim Seni Cok Sevdi', 'abc', 'Canan Tan', 'Altin Kitaplar', 'Türkiye', '11', '2016-06-21 09:10:13');
INSERT INTO `kitaplar` VALUES ('2', '1', 'Senden Once Ben', 'dyc', 'Jojo Moyes', 'Pegasus Yayinlari', 'Türkiye', '12', '2016-06-21 09:10:19');
INSERT INTO `kitaplar` VALUES ('3', '2', 'Kucuk Prens', '', 'Antoine De Saint-Exupéry', 'Can Cocuk Yayinlari', 'Turkiye', '13', '2016-06-21 09:11:28');
INSERT INTO `kitaplar` VALUES ('5', 'Cocuk', 'Olasiliksiz', 'efff', 'Adam Fawer', 'April Yayincilik', 'Turkiyewwwww', '15', '2016-06-23 12:17:40');
INSERT INTO `kitaplar` VALUES ('44', 'Cocuk', 'Olasiliksiz', 'efff', 'Adam Fawer', 'April Yayincilik', 'Turkiyeeeee', '15', '2016-06-23 12:17:26');

-- ----------------------------
-- Table structure for kitap_turleri
-- ----------------------------
DROP TABLE IF EXISTS `kitap_turleri`;
CREATE TABLE `kitap_turleri` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `kitap_turu` varchar(255) NOT NULL,
  `stant_no` varchar(255) DEFAULT NULL,
  `stant_address` varchar(255) NOT NULL,
  `eklenme_tarihi` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of kitap_turleri
-- ----------------------------
INSERT INTO `kitap_turleri` VALUES ('2', 'Cocuk', '5', 'dec', '2016-06-21 09:14:00');
INSERT INTO `kitap_turleri` VALUES ('3', 'Fantastik', '12', 'ef', '2016-06-22 11:14:24');
INSERT INTO `kitap_turleri` VALUES ('14', 'as', 'as', 'aas', '2016-06-23 09:45:46');
INSERT INTO `kitap_turleri` VALUES ('15', '1', '1', '1', '2016-06-23 09:51:03');
INSERT INTO `kitap_turleri` VALUES ('18', 'Ask', '1', '1', '2016-06-23 09:51:38');
INSERT INTO `kitap_turleri` VALUES ('21', 'aa', 'aa', 's', '2016-06-23 12:19:50');

-- ----------------------------
-- Procedure structure for fncAbc
-- ----------------------------
DROP PROCEDURE IF EXISTS `fncAbc`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fncAbc`(IN `adim` int(11))
BEGIN
select *from kitaplar where kitap_id=adim;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for fncEkleme
-- ----------------------------
DROP PROCEDURE IF EXISTS `fncEkleme`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fncEkleme`(IN  `tur_adi`varchar(255),IN `kitap_adi` varchar(255),IN `aciklama` varchar(255),IN `yazar_adi` varchar(255),IN `yayinevi` varchar(255),IN `kitap_dili` varchar(255),IN `raf_no` int)
BEGIN
insert into kitaplar values(null,kitap_turu,kitap_adi,aciklama,yazar_adi,yayinevi,kitap_dili,raf_no,now());

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for fncKitap
-- ----------------------------
DROP PROCEDURE IF EXISTS `fncKitap`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fncKitap`(IN `aranilan` varchar(255))
BEGIN
select * from kitaplar where match (kitap_adi) against (aranilan in boolean mode );
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for fncTiklama
-- ----------------------------
DROP PROCEDURE IF EXISTS `fncTiklama`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fncTiklama`(IN `table1` int(11))
BEGIN
select *from kitap_turleri where id=table1;
END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for fncTur
-- ----------------------------
DROP PROCEDURE IF EXISTS `fncTur`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fncTur`(IN `adi` varchar(255))
BEGIN
select *from kitaplar where kitap_turu=adi;
END
;;
DELIMITER ;
