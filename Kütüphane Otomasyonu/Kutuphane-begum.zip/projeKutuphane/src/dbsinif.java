




import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class dbsinif {
   
    
    
    //veritabanı bağlantısı için gerekli bilgiler
    private String dbName = "kutuphane";
    private String dbUserName = "root";
    private String dbPass = "";

    //class for name
    //dahil ettiğimiz jar dosyasını hazır hale getirir
    private String driver = "com.mysql.jdbc.Driver";

    //url bağlantı için gerekli konum
    private String url = "jdbc:mysql://localhost/";

    Connection conn = null;
    Statement st = null;

    public dbsinif() {
    }
    
    public dbsinif(String dbName){
        this.dbName = dbName;
        
    }
    public Statement baglan(){
        try {
            Class.forName(driver);
            conn = DriverManager.getConnection(url + dbName, dbUserName, dbPass);
            st = conn.createStatement();
        } catch (Exception e) {
            System.err.println("Bağlantı hatası: "+e);

        }
        return st;
    }
    
    
    
    
}
