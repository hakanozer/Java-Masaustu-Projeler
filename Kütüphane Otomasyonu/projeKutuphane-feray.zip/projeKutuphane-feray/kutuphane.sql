/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 100113
Source Host           : 127.0.0.1:3306
Source Database       : kutuphane

Target Server Type    : MYSQL
Target Server Version : 100113
File Encoding         : 65001

Date: 2016-06-24 11:08:04
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `adi` varchar(255) NOT NULL,
  `sifre` varchar(255) NOT NULL,
  PRIMARY KEY (`admin_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('1', 'begum', '1234');
INSERT INTO `admin` VALUES ('2', 'feray', '12345');
INSERT INTO `admin` VALUES ('3', 'gulll', '1');
INSERT INTO `admin` VALUES ('4', 'hakanhoca', '345');
INSERT INTO `admin` VALUES ('5', 'merve', '567');
INSERT INTO `admin` VALUES ('6', 'fatma', '89');

-- ----------------------------
-- Table structure for kitaplar
-- ----------------------------
DROP TABLE IF EXISTS `kitaplar`;
CREATE TABLE `kitaplar` (
  `kitap_id` int(11) NOT NULL AUTO_INCREMENT,
  `kitap_turu` varchar(255) DEFAULT NULL,
  `kitap_adi` varchar(255) DEFAULT NULL,
  `aciklama` varchar(255) DEFAULT NULL,
  `yazar_adi` varchar(255) DEFAULT NULL,
  `yayinevi` varchar(255) DEFAULT NULL,
  `kitap_dili` varchar(255) DEFAULT NULL,
  `raf_no` int(11) DEFAULT NULL,
  `eklenme_tarihi` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kitap_id`),
  FULLTEXT KEY `namefullindex` (`kitap_adi`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of kitaplar
-- ----------------------------
INSERT INTO `kitaplar` VALUES ('1', 'Klasikler', 'Yeraltindan Notlar', 'Yeralti Adami, insanlarinoradan oraya üsüsen karincalara dönüstügü St. Petersburgun grikaldirimlarinda itilip kakilirken, yasama istegini yavas ama eminadimlarla mutlak bir öç istegiyle degis tokus eder.', 'Dostoyevski', 'Iletisim Yayinevi', 'Türkce', '18999', '2016-06-22 11:53:14');
INSERT INTO `kitaplar` VALUES ('2', 'Klasikler', 'Madam Bovary', 'Fransiz romaninin önemli isimlerinden Flaubert, Madam Bovary adli romaninda Emma’nin kisiliginde 19. Yüzyil Fransa’sinda kadinin kistirilmis hayatini, yozlasmis evlilik kurumunun elestirisini ve sosyal deger yargilarinin, ahlak ölçülerinin ikiyüzlülügünü ', 'Gustave Flaubert', 'Karanfil Yayinlari', 'Türkce', '189', '2016-06-22 12:07:06');
INSERT INTO `kitaplar` VALUES ('3', 'Ask', 'Güzel Bir Gün', 'Yoklugumda sana rehberlik edecegine inandigim bu defter, ikimiz için de küçük bir teselli olsun…', 'Elin Hilderbrand', 'Marti Yayinlari', 'Türkce', '2', '2016-06-21 09:34:48');
INSERT INTO `kitaplar` VALUES ('22', 'Klasikler', 'seker portakali', 'agadjgjf', 'aa1', 'addgjsgjhd', 'türkce', '5', '2016-06-23 11:51:51');
INSERT INTO `kitaplar` VALUES ('24', 'Bilim Kurgu', 'Yeraltindan Notlar', 'Yeralti Adami, insanlarinoradan oraya üsüsen karincalara dönüstügü St. Petersburgun grikaldirimlarinda itilip kakilirken, yasama istegini yavas ama eminadimlarla mutlak bir öç istegiyle degis tokus eder.', 'Dostoyevski', 'Iletisim Yayinevi', 'Türkce', '18999', '2016-06-23 09:35:54');
INSERT INTO `kitaplar` VALUES ('27', 'Klasikler', 'asd', 'asttt', 'asd', 'das', 'asdasda', '12', '2016-06-23 12:34:11');
INSERT INTO `kitaplar` VALUES ('31', 'Bilim Kurgu', 'Yeraltindan Notlar', 'Yeralti Adami, insanlarinoradan oraya üsüsen karincalara dönüstügü St. Petersburgun grikaldirimlarinda itilip kakilirken, yasama istegini yavas ama eminadimlarla mutlak bir öç istegiyle degis tokus eder.', 'Dostoyevski', 'Iletisim Yayinevi', 'tr', '18999', '2016-06-23 12:17:13');
INSERT INTO `kitaplar` VALUES ('33', 'Ask', 'fer', 'ferrr', 'fer', 'ee', 'fer', '5', '2016-06-23 12:34:47');

-- ----------------------------
-- Table structure for kitapturleri
-- ----------------------------
DROP TABLE IF EXISTS `kitapturleri`;
CREATE TABLE `kitapturleri` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tur_adi` varchar(255) NOT NULL,
  `stant_no` varchar(255) NOT NULL,
  `stant_adres` varchar(255) NOT NULL,
  `eklenme_tarihi` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of kitapturleri
-- ----------------------------
INSERT INTO `kitapturleri` VALUES ('1', 'Klasikler', '1', 'A', '2016-06-21 09:41:43');
INSERT INTO `kitapturleri` VALUES ('2', 'Ask', '2', 'B', '2016-06-21 09:42:30');
INSERT INTO `kitapturleri` VALUES ('9', 'bilim', '7', 'ka', '2016-06-22 12:22:39');
INSERT INTO `kitapturleri` VALUES ('15', 'aa', '6', 'c', '2016-06-22 12:07:33');
INSERT INTO `kitapturleri` VALUES ('16', 'oyku', '6', 'm', '2016-06-22 12:22:27');
INSERT INTO `kitapturleri` VALUES ('17', 'roman', '6', 'c', '2016-06-23 09:44:26');
INSERT INTO `kitapturleri` VALUES ('22', 'deneme', '7', 'c', '2016-06-23 12:35:02');
INSERT INTO `kitapturleri` VALUES ('25', 'romanoyku', '7', 'c', '2016-06-24 09:50:52');

-- ----------------------------
-- Procedure structure for fncKatid
-- ----------------------------
DROP PROCEDURE IF EXISTS `fncKatid`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fncKatid`(IN `adii2` int(11))
BEGIN
	select * from kitapTurleri where id=adii2;

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for fncKitap
-- ----------------------------
DROP PROCEDURE IF EXISTS `fncKitap`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fncKitap`(IN `adi` varchar(255))
BEGIN
	select * from kitaplar WHERE MATCH (kitap_adi) AGAINST(adi  IN boolean MODE) ;

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for fncKitapid
-- ----------------------------
DROP PROCEDURE IF EXISTS `fncKitapid`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fncKitapid`(IN `adii` int(11))
BEGIN
select * from kitaplar where kitap_id=adii;

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for fncTuru
-- ----------------------------
DROP PROCEDURE IF EXISTS `fncTuru`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fncTuru`(IN `kadi` varchar(255))
BEGIN
	select *from kitaplar where kitap_turu=kadi;

END
;;
DELIMITER ;
