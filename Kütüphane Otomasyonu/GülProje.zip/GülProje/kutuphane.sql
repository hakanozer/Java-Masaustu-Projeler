/*
Navicat MySQL Data Transfer

Source Server         : localhost
Source Server Version : 100113
Source Host           : localhost:3306
Source Database       : kutuphane

Target Server Type    : MYSQL
Target Server Version : 100113
File Encoding         : 65001

Date: 2016-06-24 11:41:47
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adi` varchar(255) CHARACTER SET utf8 COLLATE utf8_turkish_ci NOT NULL,
  `sifre` varchar(255) CHARACTER SET utf8 COLLATE utf8_turkish_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('1', 'gul', '12');

-- ----------------------------
-- Table structure for kitaplar
-- ----------------------------
DROP TABLE IF EXISTS `kitaplar`;
CREATE TABLE `kitaplar` (
  `kitap_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `kitap_turu` varchar(255) CHARACTER SET utf8 COLLATE utf8_turkish_ci NOT NULL,
  `kitap_adi` varchar(255) CHARACTER SET utf8 COLLATE utf8_turkish_ci DEFAULT NULL,
  `aciklama` varchar(255) CHARACTER SET utf8 COLLATE utf8_turkish_ci DEFAULT NULL,
  `yazar_adi` varchar(255) CHARACTER SET utf8 COLLATE utf8_turkish_ci DEFAULT NULL,
  `yayinevi` varchar(255) CHARACTER SET utf8 COLLATE utf8_turkish_ci DEFAULT NULL,
  `kitap_dili` varchar(255) CHARACTER SET utf8 COLLATE utf8_turkish_ci DEFAULT NULL,
  `raf_no` int(11) DEFAULT NULL,
  `eklenme_tarihi` datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`kitap_id`),
  FULLTEXT KEY `full_index` (`kitap_adi`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of kitaplar
-- ----------------------------
INSERT INTO `kitaplar` VALUES ('11', 'Cocuk', 'kucuk prens', 'aaa', 'jojo', 'agac', 'Türkce', '98', '2016-06-24 09:49:11');
INSERT INTO `kitaplar` VALUES ('24', 'Cocuk', 'yty', 'aaaaaa', 'yy', 'y', 'yy', '6', '2016-06-24 10:16:35');
INSERT INTO `kitaplar` VALUES ('31', 'Ask', 'aaaa', 'f', 'ffff', 'ft', 'f', '4', '2016-06-24 11:26:11');
INSERT INTO `kitaplar` VALUES ('32', 'Ask', 'yty', 'aaaaaa', 'yy', 'y', 'yy', '6', '2016-06-24 11:26:17');

-- ----------------------------
-- Table structure for kitapturleri
-- ----------------------------
DROP TABLE IF EXISTS `kitapturleri`;
CREATE TABLE `kitapturleri` (
  `tur_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `kitap_turu` varchar(255) CHARACTER SET utf8 COLLATE utf8_turkish_ci NOT NULL,
  `stant_no` varchar(255) CHARACTER SET utf8 COLLATE utf8_turkish_ci NOT NULL,
  `stant_adres` varchar(255) CHARACTER SET utf8 COLLATE utf8_turkish_ci NOT NULL,
  `eklenme_tarihi` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`tur_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of kitapturleri
-- ----------------------------
INSERT INTO `kitapturleri` VALUES ('2', 'Cocuk', '5', 'C Blok', '2016-06-21 12:13:49');
INSERT INTO `kitapturleri` VALUES ('15', 'Egitim', '154', 'B Blok', '2016-06-24 09:09:39');
INSERT INTO `kitapturleri` VALUES ('24', 'Ask', '34', 'A Blok', '2016-06-24 10:37:26');
INSERT INTO `kitapturleri` VALUES ('39', 'üğişçö', '3', 'dfgdf', '2016-06-24 11:04:17');
INSERT INTO `kitapturleri` VALUES ('40', 'tt', 'yty', '4ff', '2016-06-24 11:00:11');
INSERT INTO `kitapturleri` VALUES ('41', 'rtrt', 't', 'tet', '2016-06-24 11:04:11');
INSERT INTO `kitapturleri` VALUES ('42', 'ff', 'ff', 'ff', '2016-06-24 11:04:31');
INSERT INTO `kitapturleri` VALUES ('43', 'er', 'er', 'er', '2016-06-24 11:05:12');

-- ----------------------------
-- Procedure structure for giris
-- ----------------------------
DROP PROCEDURE IF EXISTS `giris`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `giris`(IN `gadi` varchar(255),IN `gsifre` varchar(255))
BEGIN
	
select * from admin where adi=gadi AND sifre=gsifre;

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for kitapAdi
-- ----------------------------
DROP PROCEDURE IF EXISTS `kitapAdi`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `kitapAdi`(IN `adi` varchar(255))
BEGIN

SELECT *FROM kitaplar where kitap_adi LIKE CONCAT('%',adi, '%') or kitap_turu like CONCAT('%',adi, '%')   ;

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for kitapIdSecme
-- ----------------------------
DROP PROCEDURE IF EXISTS `kitapIdSecme`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `kitapIdSecme`(IN `ksid` int)
BEGIN

	SELECT* FROM kitaplar LEFT JOIN kitapturleri ON kitaplar.kitap_turu=kitapturleri.kitap_turu WHERE kitap_id=ksid;

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for kitapTuruEkle
-- ----------------------------
DROP PROCEDURE IF EXISTS `kitapTuruEkle`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `kitapTuruEkle`(IN `katAdi` varchar(255),IN `stantNo`  varchar(255),IN `stantAdres` varchar(255))
BEGIN

	insert into kitapturleri values(null,katAdi,stantNo,standAdres,now());

END
;;
DELIMITER ;

-- ----------------------------
-- Procedure structure for kullanici
-- ----------------------------
DROP PROCEDURE IF EXISTS `kullanici`;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `kullanici`(IN `yadi` varchar(255),IN `ysifre` varchar(255))
BEGIN
	
update admin set adi= yadi , sifre=ysifre where id = '1';

END
;;
DELIMITER ;
