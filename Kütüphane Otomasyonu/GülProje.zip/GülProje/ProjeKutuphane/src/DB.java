


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;

public class DB {
     
   private String dbName="kutuphane";
   private String dbUserName="root";
   private String dbPass="";
  
   private String driver="com.mysql.jdbc.Driver";
   
   private String url="jdbc:mysql://localhost/";
   
    Connection conn=null;
    Statement st=null;

    public DB() {
    }
  
    
    public DB(String dbName){
    this.dbName=dbName;
    
    }
    
    //bağlan methodu 
    public Statement baglan(){
        try {
            Class.forName(driver);
            conn=DriverManager.getConnection(url+dbName+"?useUnicode=true&characterEncoding=utf-8",dbUserName,dbPass);
            st=conn.createStatement();
            
        } catch (Exception e) {
            System.err.println("Bağlantı Hatası" +e);
        
        }
            return st;
        
    
    
    }
    
    
    
    
    
     
}
